import assert from 'node:assert/strict';
import {test} from 'node:test';
import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import {EventEmitter} from 'node:events';
import {createSetupController,startSetupServer,safeSetupText,windowsArgument} from '../setup.mjs';
const deferred=()=>{let resolve;const promise=new Promise(r=>resolve=r);return {promise,resolve};};
async function fixture(extra={}){const directory=await fs.mkdtemp(path.join(os.tmpdir(),'qwen-setup-test-'));const done=deferred();let calls=0,shutdown=0,dependencies;
 const controller=await createSetupController({preferenceFile:path.join(directory,'prefs.json'),hasRememberedToken:async()=>true,openFolder:async p=>p,launch:async(args,deps)=>{calls++;dependencies=deps;deps.onProgress({stage:'loading',state:'running',detail:'Loading the exact Qwen model on two GPUs.',percent:35});return {session:{owner:'fixture',url:'https://www.kaggle.com/code/fixture/qwen-agent-fixture'},done:done.promise,close:async()=>{shutdown++;done.resolve({code:0});}};},...extra});
 return {controller,directory,done,get calls(){return calls;},get shutdown(){return shutdown;},get dependencies(){return dependencies;},async close(){done.resolve({code:0});await controller.close();const target=path.resolve(directory);assert(target.startsWith(path.resolve(os.tmpdir())+path.sep)&&path.basename(target).startsWith('qwen-setup-test-'));await fs.rm(target,{recursive:true,force:true});}};
}
const choices={folder:'C:/example/project',gpuConsent:true,installConsent:true,browser:true,rememberToken:true};
test('GUI cannot launch before personal GPU consent and no credentials appear in snapshots',async()=>{const f=await fixture();try{assert.throws(()=>f.controller.start({...choices,gpuConsent:false}),e=>e.code==='consent_required');assert.equal(f.calls,0);const password='KGAT_fixture_01234567890123456789';const input={...choices,token:password};f.controller.start(input);assert.equal(input.token,'');await new Promise(r=>setTimeout(r,20));assert.equal(f.calls,1);assert.equal(f.controller.snapshot().phase,'ready');assert(!JSON.stringify(f.controller.snapshot()).includes(password));assert.equal(await f.dependencies.promptToken(),'', 'token reference is cleared after bootstrap');}finally{await f.close();}});
test('actual phase updates remain visible and running requires terminal acknowledgement',async()=>{const f=await fixture();try{f.controller.start({...choices});await new Promise(r=>setTimeout(r,20));assert.equal(f.controller.snapshot().phase,'ready');f.controller.terminalStarted();assert.equal(f.controller.snapshot().phase,'running');assert(f.controller.snapshot().detail.includes('close this setup window'));assert.throws(()=>f.controller.start({...choices}),e=>e.code==='setup_busy');await f.controller.cancel();await f.controller.work;assert.equal(f.shutdown,1);assert.equal(f.controller.snapshot().phase,'stopped');}finally{await f.close();}});
test('specific launch failures remain actionable and uncertain launches are not automatically retried',async()=>{let calls=0;const f=await fixture({launch:async()=>{calls++;throw Object.assign(new Error('Kaggle did not confirm this request. Check your own Kaggle notebook before starting another.'),{code:'kaggle_unknown'});}});try{f.controller.start({...choices});await f.controller.work;assert.equal(calls,1);assert.equal(f.controller.snapshot().canRetry,true);assert.equal(f.controller.snapshot().error.code,'kaggle_unknown');assert(f.controller.snapshot().detail.includes('Kaggle did not confirm'));}finally{await f.close();}});
test('cancelling before bootstrap finishes still closes its confirmed owned session',async()=>{const boot=deferred(),end=deferred();let signal,shutdown=0;const f=await fixture({launch:async(_args,deps)=>{signal=deps.signal;await boot.promise;return {done:end.promise,close:async()=>{shutdown++;end.resolve({code:0});}};}});try{f.controller.start({...choices});await new Promise(r=>setTimeout(r,10));await f.controller.cancel();assert(signal.aborted);assert.throws(()=>f.controller.start({...choices}),e=>e.code==='setup_busy');boot.resolve();await f.controller.work;assert.equal(shutdown,1);assert.equal(f.controller.snapshot().phase,'stopped');}finally{boot.resolve();end.resolve({code:0});await f.close();}});
test('closing setup cancels an owned folder dialog without changing its folder',async()=>{const started=deferred();const f=await fixture({chooseFolder:async({signal})=>{started.resolve();await new Promise(r=>signal.addEventListener('abort',r,{once:true}));return null;}});try{const picking=f.controller.folder();await started.promise;assert.throws(()=>f.controller.start({...choices}),e=>e.code==='setup_busy');await f.controller.cancel();assert.deepEqual(await picking,{folder:'',cancelled:true});}finally{await f.close();}});
test('events bound output and remove credentials, terminal controls and model tunnel URLs',async()=>{assert.equal(safeSetupText('KGAT_fixture_01234567890123456789 '+ 'a'.repeat(64)+' https://private.trycloudflare.com/path\x00'),'[redacted] [redacted] [private model connection]');const f=await fixture();try{f.controller.start({...choices});await new Promise(r=>setTimeout(r,10));for(let i=0;i<400;i++)f.dependencies.onProgress({stage:'downloading',state:'running',detail:'chunk '+i});const s=f.controller.snapshot();assert.equal(s.events.length,180);assert.equal(s.events.at(-1).text,'chunk 399');}finally{await f.close();}});
test('loopback APIs require exact origin and capability, never expose a token or terminal env',async()=>{let launches=0;const directory=await fs.mkdtemp(path.join(os.tmpdir(),'qwen-setup-test-'));const local=await startSetupServer({controllerDependencies:{preferenceFile:path.join(directory,'prefs.json'),hasRememberedToken:async()=>false,launch:async()=>{launches++;}}});try{const request=(route,options={})=>fetch(local.origin+route,options);assert.equal((await request('/api/state')).status,401);assert.equal((await request('/api/state',{headers:{authorization:'Bearer '+local.capability,origin:'https://other.invalid'}})).status,403);const state=await request('/api/state',{headers:{authorization:'Bearer '+local.capability}});assert.equal(state.status,200);assert.equal((await state.json()).rememberedToken,false);assert.equal((await request('/terminal/bootstrap',{headers:{authorization:'Bearer '+local.capability}})).status,401);const denied=await request('/api/start',{method:'POST',headers:{authorization:'Bearer '+local.capability,'content-type':'application/json'},body:JSON.stringify({...choices,gpuConsent:false})});assert.equal(denied.status,400);assert.equal(launches,0);}finally{await local.close();await fs.rm(directory,{recursive:true,force:true});}});
test('terminal handoff is one-use, separate from UI authority, and disappears when its owner exits',async()=>{const directory=await fs.mkdtemp(path.join(os.tmpdir(),'qwen-setup-test-'));let handoff,child;const end=deferred();const local=await startSetupServer({spawnTerminalHost:options=>{handoff=options;child=new EventEmitter();return child;},controllerDependencies:{preferenceFile:path.join(directory,'prefs.json'),hasRememberedToken:async()=>true,launch:async(_args,deps)=>{deps.spawnProcess(process.execPath,['--version'],{env:{QWEN_AGENT_RELAY_KEY:'private-relay-fixture'},cwd:directory,title:'Window title fixture'});return {done:end.promise,close:async()=>end.resolve({code:0})};}}});try{local.controller.start({...choices,folder:directory});await new Promise(r=>setTimeout(r,20));const get=()=>fetch(local.origin+'/terminal/bootstrap',{headers:{authorization:'Bearer '+handoff.capability}});assert.equal((await fetch(local.origin+'/terminal/bootstrap',{headers:{authorization:'Bearer '+local.capability}})).status,401);const first=await get();assert.equal(first.status,200);const handed=await first.json();assert.equal(handed.env.QWEN_AGENT_RELAY_KEY,'private-relay-fixture');assert.equal(handed.title,'Window title fixture','the console that hosts OpenCode needs the window title');assert.equal((await get()).status,409);assert(!JSON.stringify(local.controller.snapshot()).includes('private-relay-fixture'));child.emit('close',0);assert.equal((await get()).status,401);}finally{end.resolve({code:0});await local.close();await fs.rm(directory,{recursive:true,force:true});}});
test('native Windows argument quoting preserves spaces and trailing backslashes',()=>{assert.equal(windowsArgument('C:\\Some folder\\'), '"C:\\Some folder\\\\"');assert.equal(windowsArgument('a"b'),'"a\\"b"');});

test('an unconfirmed launch reference survives reopening setup and changing models stays blocked',async()=>{
  let firstId,secondId;const f=await fixture({launch:async args=>{firstId=args[args.indexOf('--launch-id')+1];throw Object.assign(new Error('Unconfirmed launch.'),{launchUncertain:true});}});
  let reopened;
  try{
    f.controller.start({...choices});await f.controller.work;
    const stored=JSON.parse(await fs.readFile(path.join(f.directory,'prefs.json'),'utf8'));
    assert.equal(stored.pendingLaunch.id,firstId);
    reopened=await createSetupController({preferenceFile:path.join(f.directory,'prefs.json'),hasRememberedToken:async()=>true,openFolder:async value=>value,launch:async args=>{secondId=args[args.indexOf('--launch-id')+1];assert.equal(args[args.indexOf('--folder')+1],choices.folder);throw Object.assign(new Error('Still uncertain.'),{launchUncertain:true});}});
    assert.throws(()=>reopened.start({...choices,modelUrl:'https://huggingface.co/example/model-GGUF'}),error=>error.code==='launch_model_pending');
    reopened.start({...choices});await reopened.work;assert.equal(secondId,firstId);
  }finally{await reopened?.close();await f.close();}
});

test('unconfirmed launches permit only an explicit same-reference retry and freeze elapsed time',async()=>{let calls=0;const ids=[];const f=await fixture({launch:async args=>{calls++;ids.push(args[args.indexOf('--launch-id')+1]);throw new Error('The personal Kaggle launch could not be confirmed. Check your notebook before trying again.');}});try{f.controller.start({...choices});await f.controller.work;const stopped=f.controller.snapshot();assert.equal(stopped.canRetry,true);assert.equal(calls,1);assert(Number.isFinite(Date.parse(stopped.startedAt)));assert(Date.parse(stopped.endedAt)>=Date.parse(stopped.startedAt));assert.equal(f.controller.snapshot().endedAt,stopped.endedAt);f.controller.start({...choices});await f.controller.work;assert.equal(calls,2);assert.equal(ids[0],ids[1]);assert(/^[a-f0-9]{32}$/.test(ids[0]));}finally{await f.close();}});
test('declined local installation gives a specific remedy without launching a notebook',async()=>{let allocated=0;const f=await fixture({launch:async(_args,deps)=>{const accepted=await deps.askSetup('Install the missing reviewed local tools: OpenCode and Playwright?');if(!accepted)return null;allocated++;}});try{f.controller.start({...choices,installConsent:false});await f.controller.work;assert.equal(allocated,0);assert.equal(f.controller.snapshot().phase,'stopped');assert.match(f.controller.snapshot().detail,/Allow installing missing local tools/);assert.equal(f.controller.snapshot().canRetry,true);}finally{await f.close();}});

test('notebook launch and transport retry never become a local tools installation stage',async()=>{const boot=deferred(),end=deferred();let progress;const f=await fixture({launch:async(_args,deps)=>{progress=deps.onProgress;progress({stage:'launching',state:'running',detail:'Submitting your private Kaggle notebook.'});await boot.promise;return {done:end.promise,close:async()=>end.resolve({code:0})};}});try{f.controller.start({...choices});while(!progress)await new Promise(r=>setTimeout(r,1));assert.equal(f.controller.snapshot().phase,'launching');assert.equal(f.controller.snapshot().title,'Starting your Kaggle notebook');progress({stage:'installing',source:'notebook',state:'running',detail:'Preparing the saved runtime',connection:'retrying'});assert.equal(f.controller.snapshot().title,'Preparing the cloud runtime');assert.equal(f.controller.snapshot().detail,'Preparing the saved runtime');assert.equal(f.controller.snapshot().connection,'retrying');}finally{boot.resolve();end.resolve({code:0});await f.close();}});

test('unchanged polled stages are not appended repeatedly to setup activity',async()=>{const f=await fixture();try{f.controller.start({...choices});await new Promise(r=>setTimeout(r,15));for(let i=0;i<100;i++)f.dependencies.onProgress({stage:'queued',source:'notebook',state:'running',detail:'Kaggle confirmed queued',elapsedSeconds:i});assert.equal(f.controller.snapshot().events.filter(e=>e.text==='Kaggle confirmed queued').length,1);}finally{await f.close();}});
test('one setup failure reported by progress and its rejection appears once with its original stage',async()=>{
  const message='Kaggle did not confirm GetKernelSessionStatus (HTTP 403).';
  const f=await fixture({launch:async(_args,deps)=>{deps.onProgress({stage:'launching',state:'error',detail:message});throw Object.assign(new Error(message),{stage:'launching',code:'personal_launch_unconfirmed',launchUncertain:true});}});
  try{f.controller.start({...choices});await f.controller.work;const state=f.controller.snapshot(),errors=state.events.filter(event=>event.text===message);assert.equal(errors.length,1);assert.equal(errors[0].level,'error');assert.equal(errors[0].stage,'launching');assert.equal(state.retrySameLaunch,true);assert.equal(state.phase,'error');}finally{await f.close();}
});
test('same activity text preserves changes in severity, stage and source',async()=>{
  const f=await fixture();try{f.controller.start({...choices});await new Promise(resolve=>setTimeout(resolve,15));
    const detail='Notebook status changed.';
    for(const event of [{stage:'queued',state:'running'},{stage:'queued',state:'error'},{stage:'connecting',state:'error'},{stage:'connecting',state:'error',source:'notebook'}])f.dependencies.onProgress({...event,detail});
    const events=f.controller.snapshot().events.filter(event=>event.text===detail);assert.equal(events.length,4);assert.deepEqual(events.map(({stage,level,source})=>({stage,level,source})),[{stage:'queued',level:'info',source:undefined},{stage:'queued',level:'error',source:undefined},{stage:'connecting',level:'error',source:undefined},{stage:'connecting',level:'error',source:'notebook'}]);
  }finally{await f.close();}
});
test('a token remembered before launch failure is available to an explicit retry without another paste',async()=>{
  let saved=false,calls=0;const f=await fixture({hasRememberedToken:async()=>saved,launch:async(_args,deps)=>{calls++;if(calls===1){assert.match(await deps.promptToken(),/^KGAT_/);saved=true;}else assert.equal(await deps.promptToken(),'');throw Object.assign(new Error('Notebook status remains unconfirmed.'),{launchUncertain:true});}});
  try{f.controller.start({...choices,token:'KGAT_fixture_01234567890123456789'});await f.controller.work;assert.equal(f.controller.snapshot().rememberedToken,true);assert.equal(calls,1);f.controller.start({...choices});await f.controller.work;assert.equal(calls,2);assert.equal(f.controller.snapshot().rememberedToken,true);}finally{await f.close();}
});
test('deleted-notebook recovery requires its current safe error and a fresh explicit checkbox choice',async()=>{
  const notebookUrl='https://www.kaggle.com/code/fixture/qwen-agent-'+'b'.repeat(24),attempts=[];
  const f=await fixture({launch:async args=>{attempts.push(args);throw Object.assign(new Error('Kaggle could not verify the old notebook.'),{code:'personal_notebook_inaccessible',launchUncertain:true,canConfirmDeleted:true,notebookUrl});}});let reopened;
  try{
    assert.throws(()=>f.controller.start({...choices,confirmDeletedNotebooks:true}),error=>error.code==='recovery_not_available');
    assert.throws(()=>f.controller.start({...choices,confirmDeletedNotebooks:'true'}),error=>error.code==='invalid_recovery_confirmation');
    f.controller.start({...choices});await f.controller.work;assert.equal(f.controller.snapshot().error.canConfirmDeleted,true);assert.equal(f.controller.snapshot().error.notebookUrl,notebookUrl);assert.match(f.controller.snapshot().detail,/does not delete Kaggle files/);
    f.controller.start({...choices});await f.controller.work;
    f.controller.start({...choices,confirmDeletedNotebooks:true});await f.controller.work;
    f.controller.start({...choices});await f.controller.work;
    assert.deepEqual(attempts.map(args=>args.includes('--confirm-deleted-notebooks')),[false,false,true,false]);assert.equal(new Set(attempts.map(args=>args[args.indexOf('--launch-id')+1])).size,1);
    const saved=await fs.readFile(path.join(f.directory,'prefs.json'),'utf8');assert(!saved.includes('confirmDeleted'));assert(!saved.includes(notebookUrl));
    reopened=await createSetupController({preferenceFile:path.join(f.directory,'prefs.json'),hasRememberedToken:async()=>true});assert.equal(reopened.snapshot().error,null);assert.throws(()=>reopened.start({...choices,confirmDeletedNotebooks:true}),error=>error.code==='recovery_not_available');
  }finally{await reopened?.close();await f.close();}
});
test('arbitrary recovery URLs and other error codes cannot authorize deletion confirmation',async()=>{
  for(const patch of [{notebookUrl:'https://evil.invalid/code/fixture/qwen-agent-old'},{notebookUrl:'https://www.kaggle.com/code/fixture/qwen-agent-old?token=secret'},{code:'kaggle_unknown'}]){
    const f=await fixture({launch:async()=>{throw Object.assign(new Error('Notebook lookup failed.'),{code:'personal_notebook_inaccessible',canConfirmDeleted:true,launchUncertain:true,notebookUrl:'https://www.kaggle.com/code/fixture/qwen-agent-old',...patch});}});
    try{f.controller.start({...choices});await f.controller.work;assert.equal(f.controller.snapshot().error.canConfirmDeleted,undefined);assert.throws(()=>f.controller.start({...choices,confirmDeletedNotebooks:true}),error=>error.code==='recovery_not_available');}finally{await f.close();}
  }
});
test('custom model links are Hugging Face GGUF only and invalid hosts never launch',async()=>{const f=await fixture();try{assert.throws(()=>f.controller.start({...choices,modelUrl:'https://ollama.com/library/qwen'}),/Hugging Face GGUF only/);assert.equal(f.calls,0);f.controller.start({...choices,modelUrl:'https://huggingface.co/example/model-GGUF'});await new Promise(r=>setTimeout(r,15));assert.equal(f.controller.snapshot().modelUrl,'https://huggingface.co/example/model-GGUF');}finally{await f.close();}});

async function setupPage(initial){
  class Element{
    constructor(){this.value='';this.checked=false;this.disabled=false;this.hidden=false;this.children=[];this.dataset={};this.listeners={};this.scrollHeight=100;this.clientHeight=100;this.scrollTop=0;this.textContent='';}
    addEventListener(name,handler){this.listeners[name]=handler;}setAttribute(){}removeAttribute(){}focus(){}append(...nodes){this.children.push(...nodes);}replaceChildren(...nodes){this.children=nodes;}querySelector(){return null;}
  }
  const elements=new Map(),posts=[];const element=id=>{if(!elements.has(id))elements.set(id,new Element());return elements.get(id);};
  element('confirm-deleted-notebooks').checked=true; // Browsers can restore form controls on reload.
  const source=await fs.readFile(new URL('../setup-public/setup.js',import.meta.url),'utf8');
  const html=await fs.readFile(new URL('../setup-public/index.html',import.meta.url),'utf8');
  const recoveryInput=/<input\b[^>]*id="confirm-deleted-notebooks"[^>]*>/.exec(html)?.[0];assert(recoveryInput);assert(!/\bchecked\b/.test(recoveryInput));
  const response=value=>({ok:true,json:async()=>value});
  const fetcher=async(url,options)=>{if(url==='/api/state')return response(initial);if(url==='/api/ping')return response({ok:true});if(url==='/api/events')return new Promise(()=>{});if(url==='/api/start'){posts.push(JSON.parse(options.body));return response(initial);}throw new Error('Unexpected local UI route '+url);};
  const document={getElementById:element,createElement:()=>new Element(),createElementNS:()=>new Element(),createDocumentFragment:()=>new Element(),querySelector:()=>null,addEventListener(){},hidden:true,body:{dataset:{}}};
  const execute=new(Object.getPrototypeOf(async function(){}).constructor)('document','location','sessionStorage','history','fetch','setInterval','setTimeout','clearTimeout','window','navigator','matchMedia',source+'\nreturn {render};');
  const controls=await execute(document,{hash:'#'+'a'.repeat(64),pathname:'/',search:''},{getItem:()=>null,setItem(){}},{replaceState(){}},fetcher,()=>0,()=>0,()=>{},{addEventListener(){}},{sendBeacon(){}},()=>({matches:false}));
  element('gpu-consent').checked=true;
  return {element,posts,controls,submit:()=>element('setup-form').listeners.submit({preventDefault(){}})};
}
test('recovery checkbox appears only for its safe error and never authorizes a later retry automatically',async()=>{
  const error={code:'personal_notebook_inaccessible',message:'Check your old notebook.',canConfirmDeleted:true,notebookUrl:'https://www.kaggle.com/code/fixture/qwen-agent-'+'c'.repeat(24)};
  const initial={phase:'error',folder:choices.folder,rememberedToken:true,canRetry:true,retrySameLaunch:true,error,events:[]};
  const ui=await setupPage(initial);assert.equal(ui.element('deleted-notebook-recovery').hidden,false);assert.equal(ui.element('confirm-deleted-notebooks').checked,false);assert.equal(ui.element('deleted-notebook-link').href,error.notebookUrl);
  await ui.submit();assert.equal(ui.posts[0].confirmDeletedNotebooks,undefined);
  ui.element('confirm-deleted-notebooks').checked=true;await ui.submit();assert.equal(ui.posts[1].confirmDeletedNotebooks,true);assert.equal(ui.element('confirm-deleted-notebooks').checked,false);
  await ui.submit();assert.equal(ui.posts[2].confirmDeletedNotebooks,undefined);
  ui.controls.render({...initial,error:null});assert.equal(ui.element('deleted-notebook-recovery').hidden,true);
  ui.controls.render({...initial,error:{...error,notebookUrl:'https://evil.invalid/notebook'}});assert.equal(ui.element('deleted-notebook-recovery').hidden,true);assert.equal(ui.element('confirm-deleted-notebooks').checked,false);
  const reopened=await setupPage(initial);assert.equal(reopened.element('confirm-deleted-notebooks').checked,false);
});

test('continuing the last conversation is an explicit, remembered choice passed to the launcher',async()=>{
  const directory=await fs.mkdtemp(path.join(os.tmpdir(),'qwen-setup-test-'));const seen=[];
  const start=async extra=>{const end=deferred();const local=await startSetupServer({controllerDependencies:{preferenceFile:path.join(directory,'prefs.json'),hasRememberedToken:async()=>true,launch:async(args,deps)=>{seen.push({args,readQuota:typeof deps.readQuota});return {done:end.promise,close:async()=>end.resolve({code:0})};}}});
    try{const before=local.controller.snapshot().resume,count=seen.length;local.controller.start({...choices,folder:directory,...extra});for(let i=0;i<200&&seen.length===count;i++)await new Promise(r=>setTimeout(r,10));assert.equal(seen.length,count+1,'the launcher was not reached');return before;}finally{end.resolve({code:0});await local.close();}};
  const remembered=async()=>{for(let i=0;i<150;i++){try{if(JSON.parse(await fs.readFile(path.join(directory,'prefs.json'),'utf8')).resume===true)return true;}catch{}await new Promise(r=>setTimeout(r,20));}return false;};
  try{
    assert.equal(await start({}),false,'off until chosen');assert(!seen[0].args.includes('--continue'));assert.equal(seen[0].readQuota,'function','guided setup reads the GPU allowance before launch');
    await start({resume:true});assert(seen[1].args.includes('--continue'));assert.equal(await remembered(),true,'the choice is saved with the other setup preferences');
    assert.equal(await start({resume:true}),true,'the choice is remembered for the next setup window');
    await start({resume:'yes'});assert(!seen[3].args.includes('--continue'),'only an explicit true continues');
  }finally{await fs.rm(directory,{recursive:true,force:true});}
});
