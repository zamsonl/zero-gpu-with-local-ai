@echo off
call "%~dp0app\Start Qwen OpenCode.cmd" %*
